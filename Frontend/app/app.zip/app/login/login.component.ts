// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
// import { AuthService } from '../services/auth.service';
// import { CookieService } from 'ngx-cookie-service';

// @Component({
//   selector: 'app-login',
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })
// export class LoginComponent implements OnInit {


// author={
//   email:'',
//   password:''
// }

//   constructor(private _auth: AuthService , private router: Router , private cookieService: CookieService) { }

//   ngOnInit(): void {
//   }

//   token : any;
//   login(){

//     this._auth.login(this.author)
//       .subscribe(
//         res=>{

//           this.token = res;
          
//           localStorage.setItem('token' , this.token.myToken)
//           this.cookieService.set('token', this.token.myToken, { expires: 7, path: '/' });
//           this.router.navigate(['/home']);

//         },
//         err=>{
//           console.log(err);
          
//         }
//       );

//   }

// }



import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


author={
  email:'',
  password:''
}

  constructor(private _auth: AuthService , private router: Router , private cookieService: CookieService) { }

  ngOnInit(): void {
  }

  token : any;
  login(){

    this._auth.login(this.author)
      .subscribe(
        res=>{

          this.token = res;
          
          localStorage.setItem('token' , this.token.myToken)
          this.cookieService.set('token', this.token.myToken, { expires: 7, path: '/' });
          this.router.navigate(['/home']);

        },
        err=>{
          console.log(err);
          
        }
      );

  }

}
