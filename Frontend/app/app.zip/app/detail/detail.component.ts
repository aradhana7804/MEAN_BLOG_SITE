// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';
// import { DataService } from '../services/data.service';

// @Component({
//   selector: 'app-detail',
//   templateUrl: './detail.component.html',
//   styleUrls: ['./detail.component.css']
// })
// export class DetailComponent implements OnInit {

//   id: any;
//   article: any;

//   constructor(private act: ActivatedRoute , private data : DataService) { }


  

//   ngOnInit(): void {

//     this.id = this.act.snapshot.paramMap.get('id');

//     this.data.getArticleById(this.id)
//       .subscribe(
//         res=>{
//           this.article = res;
//         }
//       )

//   }

// }






// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute, Router } from '@angular/router'; // Added Router for redirection
// import { DataService } from '../services/data.service';

// @Component({
//   selector: 'app-detail',
//   templateUrl: './detail.component.html',
//   styleUrls: ['./detail.component.css']
// })
// export class DetailComponent implements OnInit {

//   id: string | null = null;
//   article: any;

//   constructor(private act: ActivatedRoute, private data: DataService, private router: Router) { }

//   ngOnInit(): void {
//     this.id = this.act.snapshot.paramMap.get('id');

//     if (this.id) {
//       this.data.getArticleById(this.id).subscribe(
//         res => {
//           this.article = res;
//         },
//         err => {
//           console.error('Error fetching article:', err);
//         }
//       );
//     }
//   }

//   deleteArticle(id: string): void {
//     if (id && confirm('Are you sure you want to delete this article?')) {
//       this.data.deleteArticleById(id).subscribe(
//         res => {
//           alert('Article deleted successfully!');
//           this.router.navigate(['/']); // Redirect to homepage after deletion
//         },
//         err => {
//           console.error('Error deleting article:', err);
//           alert('Failed to delete the article.');
//         }
//       );
//     }
//   }
  
// }



// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute, Router } from '@angular/router';
// import { DataService } from '../services/data.service';
// import { AuthService } from '../services/auth.service'; // Import AuthService

// @Component({
//   selector: 'app-detail',
//   templateUrl: './detail.component.html',
//   styleUrls: ['./detail.component.css']
// })
// export class DetailComponent implements OnInit {

//   id: string | null = null;
//   article: any;
//   isAuthor: boolean = false;

//   constructor(
//     private act: ActivatedRoute,
//     private data: DataService,
//     private auth: AuthService, // Inject AuthService
//     private router: Router
//   ) { }

//   ngOnInit(): void {
//     this.id = this.act.snapshot.paramMap.get('id');

//     if (this.id) {
//       this.data.getArticleById(this.id).subscribe(
//         res => {
//           this.article = res;
//           this.checkAuthorization(); // Call authorization check after fetching article
//         },
//         err => {
//           console.error('Error fetching article:', err);
//         }
//       );
//     }
//   }

//   checkAuthorization(): void {
//     if (!this.auth.isLoggedIn()) {
//       this.isAuthor = false;
//       return;
//     }

//     const userData = this.auth.getAuthorDataFromToken();
//     if (userData && userData.id) {
//       this.isAuthor = this.article?.authorId === userData.id;
//     } else {
//       this.isAuthor = false;
//     }
//   }

//   deleteArticle(id: string): void {
//     if (id && confirm('Are you sure you want to delete this article?')) {
//       this.data.deleteArticleById(id).subscribe(
//         res => {
//           alert('Article deleted successfully!');
//           this.router.navigate(['/']); // Redirect to homepage after deletion
//         },
//         err => {
//           console.error('Error deleting article:', err);
//           alert('Failed to delete the article.');
//         }
//       );
//     }
//   }
// }


// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute, Router } from '@angular/router';
// import { DataService } from '../services/data.service';
// import { AuthService } from '../services/auth.service'; // Import AuthService

// @Component({
//   selector: 'app-detail',
//   templateUrl: './detail.component.html',
//   styleUrls: ['./detail.component.css']
// })
// export class DetailComponent implements OnInit {

//   id: string | null = null;
//   article: any;
//   isAuthor: boolean = false;

//   constructor(
//     private act: ActivatedRoute,
//     private data: DataService,
//     private auth: AuthService, // Inject AuthService
//     private router: Router
//   ) { }

//   ngOnInit(): void {
//     this.id = this.act.snapshot.paramMap.get('id');

//     if (this.id) {
//       this.data.getArticleById(this.id).subscribe(
//         res => {
//           this.article = res;
//           console.log("Article Data:", this.article); // Debugging article data
//           this.checkAuthorization(); // Call authorization check after fetching article
//         },
//         err => {
//           console.error('Error fetching article:', err);
//         }
//       );
//     }
//   }

//   checkAuthorization(): void {
//     console.log("Checking authorization...");

//     if (!this.auth.isLoggedIn()) {
//         console.log("User is NOT logged in.");
//         this.isAuthor = false;
//         // this.router.navigate(['/login']);
//         return;
//     }

//     const userData = this.auth.getAuthorDataFromToken();


//     if (userData && userData._id) {  
       
        
//         this.isAuthor = this.article?.idAuthor === userData._id; // Fix: Compare with _id

//         console.log("Is User the Author?:", this.isAuthor);
//     } else {
//         this.isAuthor = false;
//         console.log("No valid user ID found in token.");
//     }
// }
  

//   deleteArticle(id: string): void {
//     if (id && confirm('Are you sure you want to delete this article?')) {
//       this.data.deleteArticleById(id).subscribe(
//         res => {
//           alert('Article deleted successfully!');
//           this.router.navigate(['/']); 
//         },
//         err => {
//           console.error('Error deleting article:', err);
//           alert('Failed to delete the article.');
//         }
//       );
//     }
//   }

 


// }

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../services/data.service';
import { AuthService } from '../services/auth.service'; // Import AuthService

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {

  id: string | null = null;
  article: any;
  isAuthor: boolean = false;

  constructor(
    private act: ActivatedRoute,
    private data: DataService,
    private auth: AuthService, // Inject AuthService
    private router: Router
  ) { }

  ngOnInit(): void {
    this.id = this.act.snapshot.paramMap.get('id');

    if (this.id) {
      this.data.getArticleById(this.id).subscribe(
        res => {
          this.article = res;
          console.log("Article Data:", this.article); // Debugging article data
          this.checkAuthorization(); // Call authorization check after fetching article
          this.loadDisqusScript(); // Load Disqus comments section
        },
        err => {
          console.error('Error fetching article:', err);
        }
      );
    }
  }

  checkAuthorization(): void {
    console.log("Checking authorization...");

    if (!this.auth.isLoggedIn()) {
        console.log("User is NOT logged in.");
        this.isAuthor = false;
        // this.router.navigate(['/login']);
        return;
    }

    const userData = this.auth.getAuthorDataFromToken();

    if (userData && userData._id) {  
        this.isAuthor = this.article?.idAuthor === userData._id; // Fix: Compare with _id
        console.log("Is User the Author?:", this.isAuthor);
    } else {
        this.isAuthor = false;
        console.log("No valid user ID found in token.");
    }
  }

  deleteArticle(id: string): void {
    if (id && confirm('Are you sure you want to delete this article?')) {
      this.data.deleteArticleById(id).subscribe(
        res => {
          alert('Article deleted successfully!');
          this.router.navigate(['/']); 
        },
        err => {
          console.error('Error deleting article:', err);
          alert('Failed to delete the article.');
        }
      );
    }
  }

  loadDisqusScript(): void {
    // Dynamically inject the Disqus script after the view is initialized
    const script = document.createElement('script');
    script.src = 'https://personalblogsite.disqus.com/embed.js';

    // Ensure the timestamp is cast correctly to a number
    script.setAttribute('data-timestamp', String(+new Date()));  // Explicitly cast to string

    script.async = true;
    document.body.appendChild(script);

    // Configure Disqus for this article
    (window as any).disqus_config = function () {
      this.page.url = `http://localhost:4200/article/${this.article._id}`; // Dynamic URL for Disqus
      this.page.identifier = this.article._id; // Unique identifier for Disqus
    };
  }

}
