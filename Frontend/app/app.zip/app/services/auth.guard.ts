// import { Injectable } from '@angular/core';
// import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
// import { Observable } from 'rxjs';
// import { AuthService } from './auth.service';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthGuard implements CanActivate {

//   constructor( private _auth: AuthService , private router: Router ){}
  
//   canActivate(){
//     if(this._auth.isLoggedIn()){
//       return true;
//     }else{
//       this.router.navigate(['/login'])
//       return false;
//     }
//   }

// }
import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private _auth: AuthService, private router: Router) {}

  canActivate(): boolean {
    const token = this.getTokenFromCookies(); // Get token from cookies

    if (token && this._auth.isLoggedIn()) {
      return true;
    } else if (!token) {
      this.router.navigate(['/unauthorized']); // Redirect to unauthorized if no token
      return false;
    } else {
      this.router.navigate(['/login']); // Redirect to login if token exists but user is not logged in
      return false;
    }
  }

  private getTokenFromCookies(): string | null {
    const name = 'token=';
    const decodedCookies = decodeURIComponent(document.cookie).split(';');
    
    for (let cookie of decodedCookies) {
      while (cookie.charAt(0) === ' ') {
        cookie = cookie.substring(1);
      }
      if (cookie.indexOf(name) === 0) {
        return cookie.substring(name.length, cookie.length);
      }
    }
    return null;
  }
}
