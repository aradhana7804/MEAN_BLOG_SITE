import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  author: any = {
    name: '',
    lastname: '',
    email: '',
    about: '',
    image: ''
  };
  image: any;
  authorId: string = '';

  constructor(
    private route: ActivatedRoute,
    private _auth: AuthService,
    private data: DataService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.authorId = this._auth.getAuthorDataFromToken()?._id;
    if (!this.authorId) {
      alert("Unauthorized access!");
      this.router.navigate(['/login']);
      return;
    }
    this.getProfileDetails();
  }

  getProfileDetails() {
    this._auth.getById(this.authorId).subscribe(
      (res: any) => {
        this.author = res;
      },
      err => {
        console.log('Error fetching profile:', err);
      }
    );
  }
  

  select(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.image = file;
      const reader = new FileReader();
      reader.onload = () => {
        this.author.image = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  }

  updateProfile() {
    let fd = new FormData();
    fd.append('name', this.author.name);
    fd.append('lastname', this.author.lastname);
    fd.append('email', this.author.email);
    fd.append('about', this.author.about);
    if (this.image) {
      fd.append('image', this.image);
    }
  
    const authorId = this.authorId; // Ensure authorId is set correctly
  
    this._auth.updateProfile(authorId, fd).subscribe(
      res => {
        alert('Profile updated successfully!');
        this.router.navigate([`/author/${authorId}`]);
      },
      err => {
        console.error('Error updating profile:', err);
        alert('Failed to update profile.');
      }
    );
  }

  ChangePassword() {
    this.router.navigate(['/change-password']); // Adjust the route as needed
  }




  
}




















// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute, Router } from '@angular/router';
// import { AuthService } from '../services/auth.service';

// @Component({
//   selector: 'app-edit-profile',
//   templateUrl: './edit-profile.component.html',
//   styleUrls: ['./edit-profile.component.css']
// })
// export class EditProfileComponent implements OnInit {
//   author: any = {
//     name: '',
//     lastname: '',
//     email: '',
//     about: '',
//     image: ''
//   };
//   image: any;
//   authorId: string = '';
//   showPreview: boolean = false; // Controls preview modal visibility

//   constructor(
//     private route: ActivatedRoute,
//     private _auth: AuthService,
//     private router: Router
//   ) {}

//   ngOnInit(): void {
//     this.authorId = this._auth.getAuthorDataFromToken()?._id;
//     if (!this.authorId) {
//       alert("Unauthorized access!");
//       this.router.navigate(['/login']);
//       return;
//     }
//     this.getProfileDetails();
//   }

//   getProfileDetails() {
//     this._auth.getById(this.authorId).subscribe(
//       (res: any) => {
//         this.author = res;
//       },
//       err => {
//         console.log('Error fetching profile:', err);
//       }
//     );
//   }

//   select(event: any): void {
//     const file = event.target.files[0];
//     if (file) {
//       this.image = file;

//       // Create a temporary image preview URL
//       const reader = new FileReader();
//       reader.onload = () => {
//         this.author.image = reader.result as string; // Update the UI with the new image preview
//       };
//       reader.readAsDataURL(file);
//     }
//   }

//   openPreview() {
//     this.showPreview = true;
//   }

//   closePreview() {
//     this.showPreview = false;
//   }

//   updateProfile() {
//     let fd = new FormData();
//     fd.append('name', this.author.name);
//     fd.append('lastname', this.author.lastname);
//     fd.append('email', this.author.email);
//     fd.append('about', this.author.about);
//     if (this.image) {
//       fd.append('image', this.image);
//     }
  
//     this._auth.updateProfile(this.authorId, fd).subscribe(
//       res => {
//         alert('Profile updated successfully!');
//         this.router.navigate(['/home']);
//       },
//       err => {
//         console.error('Error updating profile:', err);
//         alert('Failed to update profile.');
//       }
//     );
//   }
// }
