import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-unsubscribe',
  templateUrl: './unsubscribe.component.html',
  styleUrls: ['./unsubscribe.component.css']
})
export class UnsubscribeComponent implements OnInit {

  message: string = '';
  icon: string = 'unsubscribe';

  constructor(private route: ActivatedRoute, private http: HttpClient) {}

  ngOnInit(): void {
    const email = this.route.snapshot.queryParamMap.get('email');

    if (email) {
      this.http.get(`http://localhost:3000/article/unsubscribe?email=${email}`)
        .subscribe({
          next: (res: any) => {
            console.log('Unsubscribe success:', res);
            this.message = 'You have been unsubscribed.';
          },
          error: (err) => {
            this.icon = 'error';
            this.message = 'Unsubscribe failed or email not found.';
            console.error('Unsubscribe error:', err);
          }
        });
    } else {
      this.icon = 'error_outline';
      this.message = 'Invalid unsubscribe request.';
    }
  }
}
