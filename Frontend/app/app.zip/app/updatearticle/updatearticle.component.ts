import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-updatearticle',
  templateUrl: './updatearticle.component.html',
  styleUrls: ['./updatearticle.component.css']
})
export class UpdateArticleComponent implements OnInit {

  article: any = {
    title: '',
    content: '',
    tags: [],
    description: ''
  };

  tag: any = '';
  image: any;
  articleId: string = '';

  constructor(
    private route: ActivatedRoute,
    private _auth: AuthService,
    private data: DataService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.articleId = this.route.snapshot.paramMap.get('id')!;
    this.getArticleDetails();
  }

  // getArticleDetails() {
  //   this.data.getArticleById(this.articleId).subscribe(
  //     (res: any) => {
  //       this.article = res;  // Set response data to article object
  //     },
  //     err => {
  //       console.log('Error fetching article:', err);
  //     }
  //   );
  // }

  getArticleDetails() {
    this.data.getArticleById(this.articleId).subscribe(
      (res: any) => {
        const loggedInUserId = this._auth.getAuthorDataFromToken()?._id; // Get logged-in user's ID
  
        if (res.idAuthor !== loggedInUserId) {
          alert("You are not the author of this article!");
          this.router.navigate(['/unauthorizedwl']); // Redirect unauthorized users
          return;
        }
  
        this.article = res; // Set response data to article object if authorized
      },
      err => {
        console.log('Error fetching article:', err);
      }
    );
  }
  

  // select(e: any) {
  //   this.image = e.target.files[0];
  // }

  select(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.image = file;
  
      // Create a temporary image preview URL
      const reader = new FileReader();
      reader.onload = () => {
        this.article.image = reader.result as string; // Update the UI with the new image preview
      };
      reader.readAsDataURL(file);
    }
  }
  

  update() {
    let fd = new FormData();
    fd.append('title', this.article.title);
    fd.append('content', this.article.content);
    fd.append('tags', this.article.tags.toString());
    fd.append('description', this.article.description);
    if (this.image) {
      fd.append('image', this.image);
    }
    // fd.append('idAuthor', this._auth.getAuthorDataFromToken()._id);

    this.data.updateArticle(this.articleId, fd).subscribe(
      res => {
        this.router.navigate(['/home']);
      },
      err => {
        console.log('Error updating article:', err);
      }
    );
  }
}
