import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor( private http: HttpClient ) { }

  // private url = 'http://localhost:3000/author/';
  private url = 'http://localhost:3000/author/';



  register( author: any ){


    return  this.http.post(this.url + 'register' , author);

  }

  login( author: any ){


    return  this.http.post(this.url + 'login' , author);

  }

  isLoggedIn(){

    let token = localStorage.getItem('token');
    if(token){
      return true;
    }else{
      return false;

    }

  }


  // getAuthorDataFromToken(){
  //   let token = localStorage.getItem('token');
  //   if(token){
  //     let data = JSON.parse(window.atob(token.split('.')[1]))
  //     return data;
  //   }

  // }
  getAuthorDataFromToken() {
    let token = localStorage.getItem('token');
    if (!token) return null;
  
    try {
      let data = JSON.parse(atob(token.split('.')[1]));
      return data;
    } catch (error) {
      console.error("Invalid token:", error);
      return null;
    }
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }


  getById(id: any){
    return this.http.get(this.url + 'getbyid/' + id);

  }

  // updateProfile(data: FormData): Observable<any> {
  //   return this.http.put(`${this.url}update-profile`, data);
  // }

  // getById(id: string): Observable<any> {
  //   return this.http.get(`${this.url}getbyid/${id}`);
  // }

  // updateProfile(data: FormData): Observable<any> {
  //   return this.http.put(`${this.url}update-profile`, data);
  // }

  updateProfile(id: string, data: FormData): Observable<any> {
    return this.http.put(`${this.url}update-profile/${id}`, data);
  }

  changePassword(currentPassword: string, newPassword: string): Observable<any> {
    const payload = { currentPassword, newPassword };
    return this.http.put(`${this.url}change-password`, payload, { withCredentials: true });
  }

  forgotPassword(email: string): Observable<any> {
    return this.http.post(`${this.url}forgot-password`, { email });
  }

  resetPassword(token: string, newPassword: string): Observable<any> {
    return this.http.post(`${this.url}/reset-password/${token}`, { password: newPassword });
  }



  

}
