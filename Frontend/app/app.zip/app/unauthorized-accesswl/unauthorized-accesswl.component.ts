import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unauthorized-accesswl',
  templateUrl: './unauthorized-accesswl.component.html',
  styleUrls: ['./unauthorized-accesswl.component.css']
})
export class UnauthorizedAccesswlComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
