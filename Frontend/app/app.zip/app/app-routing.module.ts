import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AuthorComponent } from './author/author.component';
import { CreatearticleComponent } from './createarticle/createarticle.component';
import { DetailComponent } from './detail/detail.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { PrivacyComponent } from './privacy/privacy.component';
import { RegisterComponent } from './register/register.component';
import { AuthGuard } from './services/auth.guard';
// import { UpdateArticleComponent } from './updatearticle/updatearticle.component';
import { UpdateArticleComponent } from './updatearticle/updatearticle.component';
import { UnauthorizedAccessComponent } from './unauthorized-access/unauthorized-access.component';
import { UnauthorizedAccesswlComponent } from './unauthorized-accesswl/unauthorized-accesswl.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { LinkExpiredComponent } from './link-expired/link-expired.component';
import { UnsubscribeComponent } from './unsubscribe/unsubscribe.component';
const routes: Routes = [

  { path: '' , redirectTo: '/home' , pathMatch: 'full' },

  { path: 'home' , component: HomeComponent },
  { path: 'article/:id' , component: DetailComponent },
  { path: 'create' , canActivate:[ AuthGuard ] ,component: CreatearticleComponent },
  { path: 'about' , component: AboutComponent },

  { path: 'privacy' , component: PrivacyComponent },
  { path: 'author/:id' ,canActivate:[ AuthGuard ] , component: AuthorComponent },

  { path: 'login' , component: LoginComponent },

  { path: 'register' , component: RegisterComponent },
  { path: 'updatearticle/:id', canActivate:[ AuthGuard ] ,component: UpdateArticleComponent },

  {path:'edit-profile', component:EditProfileComponent},
  {path:'change-password', canActivate:[ AuthGuard ] ,component:ChangePasswordComponent},
  {path:'forgot-password',component:ForgotPasswordComponent},
  {path:'reset-password/:token', component: ResetPasswordComponent },


  { path: 'unauthorized' , component: UnauthorizedAccessComponent },
  { path: 'unauthorizedwl' , component: UnauthorizedAccesswlComponent },
  {path:'linkexpired',component:LinkExpiredComponent},
  {path:'unsubscribe',component:UnsubscribeComponent},



  { path: '**' , component: NotfoundComponent },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
