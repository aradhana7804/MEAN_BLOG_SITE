// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-footer',
//   templateUrl: './footer.component.html',
//   styleUrls: ['./footer.component.css']
// })
// export class FooterComponent implements OnInit {

//   constructor() { }

//   ngOnInit(): void {
//   }

// }


import { Component } from '@angular/core';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent {
  email: string = '';
  message: string = '';

  constructor(private dataService: DataService) {}

  // onSubscribe() {
  //   if (!this.email) {
  //     this.message = 'Please enter a valid email.';
  //     return;
  //   }

  //   this.dataService.subscribeToNewsletter(this.email).subscribe({
  //     next: res => this.message = res.message,
  //     error: err => this.message = err.error.message
  //   });
  // }

  onSubscribe() {
    if (!this.email) {
      this.message = 'Please enter a valid email.';
      setTimeout(() => this.message = '', 5000); // Clear after 10 seconds
      return;
    }
  
    this.dataService.subscribeToNewsletter(this.email).subscribe({
      next: res => {
        this.message = res.message;
        setTimeout(() => this.message = '', 5000); // Clear after 10 seconds
      },
      error: err => {
        this.message = err.error.message;
        setTimeout(() => this.message = '', 5000); // Clear after 10 seconds
      }
    });
  }
  
}
