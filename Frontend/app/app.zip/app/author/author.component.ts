// import { Component, OnInit } from '@angular/core';
// import { ActivatedRoute } from '@angular/router';
// import { AuthService } from '../services/auth.service';
// import { DataService } from '../services/data.service';

// @Component({
//   selector: 'app-author',
//   templateUrl: './author.component.html',
//   styleUrls: ['./author.component.css']
// })
// export class AuthorComponent implements OnInit {

//   id: any;
//   author: any;
//   articles: any;
//   publishedPosts: string = '00';
//   constructor(private act: ActivatedRoute , private _auth: AuthService , private data: DataService) { }


//   ngOnInit(): void {

//     this.id = this.act.snapshot.paramMap.get('id');
//     this._auth.getById(this.id)
//       .subscribe(
//         res=>{
//           this.author = res;
//           console.log(this.author);
          
//         }
//       );
//     // this.data.getArticleByIdAuthor(this.id)
//     //   .subscribe(
//     //     res=>{
//     //       this.articles = res;
//     //     }
//     //     ,
//     //     err=>{
//     //       console.log(err);
          
//     //     }
//     //   );    
//     this.data.getArticleByIdAuthor(this.id).subscribe({
//       next: (res) => {
//         this.articles = res;
//         this.publishedPosts = this.articles.length; // Counting published posts dynamically
//         console.log('Articles:', this.articles);
//       },
//       error: (err) => {
//         console.error('Error fetching articles:', err);
//       }
//     });

//   }

// }

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { DataService } from '../services/data.service';
import { HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-author',
  templateUrl: './author.component.html',
  styleUrls: ['./author.component.css']
})
export class AuthorComponent implements OnInit {
  id!: string | null;
  author: any = {};
  articles: any[] = [];
  searchTerm: string = '';
  publishedPosts: string = '00'; // Default value as two-digit format

  constructor(private act: ActivatedRoute, private _auth: AuthService, private data: DataService ,private router: Router ) {}

  ngOnInit(): void {
    this.id = this.act.snapshot.paramMap.get('id');
    const loggedInUserId = this._auth.getAuthorDataFromToken()?._id;

    if (this.id !== loggedInUserId) {
      alert("Unauthorized Access!"); 
      this.router.navigate(['/unauthorizedwl']); // Redirect to unauthorized page
      return;
    }

    // if (this.id) {
    //   // Fetch Author Details
    //   this._auth.getById(this.id).subscribe({
    //     next: (res) => {
    //       this.author = res;
    //       console.log('Author Data:', this.author);
    //     },
    //     error: (err) => {
    //       console.error('Error fetching author:', err);
    //     }
    //   });

    if (this.id) {
      const token = this._auth.getToken();
      const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
  
      // Fetch Author Details with token
      this._auth.getById(this.id).subscribe({
        next: (res) => {
          this.author = res;
          // console.log('Author Data:', this.author);
        },
        error: (err) => {
          console.error('Error fetching author:', err);
        }
      });

      // Fetch Articles by Author & Format Published Posts
      this.data.getArticleByIdAuthor(this.id).subscribe({
        next: (res) => {
          this.articles = res;
          this.publishedPosts = this.formatPostCount(this.articles.length);
          // console.log('Articles:', this.articles);
        },
        error: (err) => {
          console.error('Error fetching articles:', err);
        }
      });
    }
  }

        // Function to ensure two-digit formatting
        formatPostCount(count: number): string {
          return count < 10 ? `0${count}` : `${count}`;
        }

        filterByTag(tag: string) {
          this.searchTerm = tag;
        }
        
}










