import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css'],
})
export class ForgotPasswordComponent implements OnInit {
  forgotPasswordForm: FormGroup;
  message: string = '';
  loading: boolean = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.forgotPasswordForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
    });
  }

  ngOnInit(): void {}

  onSubmit() {
    if (this.forgotPasswordForm.invalid) return;

    this.loading = true;
    this.message = '';

    this.authService.forgotPassword(this.forgotPasswordForm.value.email).subscribe(
      (response) => {
        this.message = 'Reset link sent! Please check your email.';
        this.loading = false;
      },
      (error) => {
        this.message = error.error?.msg || 'Something went wrong. Try again!';
        this.loading = false;
      }
    );
  }
}
