// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class DataService {

//   constructor(private http: HttpClient) { }

//   // url = 'http://localhost:3000/article/';
//   url = 'http://localhost:3000/article/';



//   // create(article: any){
//   //   return this.http.post( this.url + 'ajout' , article  );

//   // }
  
//   create(article: any){
//     return this.http.post( this.url + 'addartical' , article  );

//   }


//   getAll(){
//     return this.http.get( this.url + 'all' );
//   }

//   getArticleByIdAuthor(id: any){
//     return this.http.get( this.url + 'getbyidauthor/' + id );
//   }


//   getArticleById(id: any){
//     return this.http.get( this.url + 'getbyid/' + id );
//   }

//   updateArticle(id: string, article: any) {
//     return this.http.put(this.url + 'update/' + id, article);
//   }

//   deleteArticleById(id: string) {
//     return this.http.delete(`http://localhost:3000/delete/${id}`);
//   }
  
  




// }

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private baseUrl = 'http://localhost:3000/article/'; // Base URL for the API

  constructor(private http: HttpClient) { }

  // Create a new article
  create(article: any): Observable<any> {
    return this.http.post(`${this.baseUrl}addartical`, article);
  }

  // Get all articles
  getAll(): Observable<any> {
    return this.http.get(`${this.baseUrl}all`);
  }

  // Get article by ID for the author
  getArticleByIdAuthor(id: string): Observable<any> {
    return this.http.get(`${this.baseUrl}getbyidauthor/${id}`);
  }

  // Get article by ID
  getArticleById(id: string): Observable<any> {
    return this.http.get(`${this.baseUrl}getbyid/${id}`);
  }

  // Update an article
  updateArticle(id: string, article: any): Observable<any> {
    return this.http.put(`${this.baseUrl}update/${id}`, article);
  }

  // Delete an article by ID
  deleteArticleById(id: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}delete/${id}`);
  }
  subscribeToNewsletter(email: string): Observable<any> {
    return this.http.post(`${this.baseUrl}subscribe`,{ email });
  }

  
  
}

