// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-change-password',
//   templateUrl: './change-password.component.html',
//   styleUrls: ['./change-password.component.css']
// })
// export class ChangePasswordComponent implements OnInit {
//   currentPassword: string = '';
//   newPassword: string = '';
//   confirmPassword: string = '';

//   showCurrentPassword: boolean = false;
//   showNewPassword: boolean = false;
//   showConfirmPassword: boolean = false;

//   constructor() {}

//   ngOnInit(): void {}

//   toggleShowCurrentPassword() {
//     this.showCurrentPassword = !this.showCurrentPassword;
//   }

//   toggleShowNewPassword() {
//     this.showNewPassword = !this.showNewPassword;
//   }

//   toggleShowConfirmPassword() {
//     this.showConfirmPassword = !this.showConfirmPassword;
//   }

//   onSubmit() {
//     if (this.newPassword !== this.confirmPassword) {
//       alert('New passwords do not match!');
//       return;
//     }

//     alert('Password changed successfully!');
//     // You can add backend integration here
//   }
// }


// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
// import { AuthService } from '../services/auth.service';

// @Component({
//   selector: 'app-change-password',
//   templateUrl: './change-password.component.html',
//   styleUrls: ['./change-password.component.css']
// })
// export class ChangePasswordComponent implements OnInit {
//   currentPassword: string = '';
//   newPassword: string = '';
//   confirmPassword: string = '';

//   showCurrentPassword: boolean = false;
//   showNewPassword: boolean = false;
//   showConfirmPassword: boolean = false;

//   constructor(private authService: AuthService, private router: Router) {}

//   ngOnInit(): void {}

//   toggleShowCurrentPassword() {
//     this.showCurrentPassword = !this.showCurrentPassword;
//   }

//   toggleShowNewPassword() {
//     this.showNewPassword = !this.showNewPassword;
//   }

//   toggleShowConfirmPassword() {
//     this.showConfirmPassword = !this.showConfirmPassword;
//   }

//   onSubmit() {
//     if (this.newPassword !== this.confirmPassword) {
//       alert('New passwords do not match!');
//       return;
//     }

//     this.authService.changePassword(this.currentPassword, this.newPassword).subscribe(
//       (response) => {
//         alert('Password changed successfully!');
//         this.router.navigate(['/login']);
//       },
//       (error) => {
//         alert('Error changing password. Please try again.');
//       }
//     );
//   }
// }


import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  currentPassword: string = '';
  newPassword: string = '';
  confirmPassword: string = '';

  showCurrentPassword: boolean = false;
  showNewPassword: boolean = false;
  showConfirmPassword: boolean = false;

  constructor(private authService: AuthService, private router: Router) {}

  ngOnInit(): void {}

  toggleShowCurrentPassword() {
    this.showCurrentPassword = !this.showCurrentPassword;
  }

  toggleShowNewPassword() {
    this.showNewPassword = !this.showNewPassword;
  }

  toggleShowConfirmPassword() {
    this.showConfirmPassword = !this.showConfirmPassword;
  }

  onSubmit() {
    if (this.newPassword !== this.confirmPassword) {
      alert('New passwords do not match!');
      return;
    }
  
    this.authService.changePassword(this.currentPassword, this.newPassword).subscribe(
      (response) => {
        alert('Password changed successfully!');
        this.router.navigate(['/edit-profile']);
      },
      (error) => {
        if (error.status === 400) {
          alert('Incorrect current password!');
        } else {
          alert('Error changing password. Please try again.');
        }
      }
    );
  }
  
}
